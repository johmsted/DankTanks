﻿using System;


namespace InControl
{
	public enum BindingSourceRejectionType : int
	{
		None = 0,
		DuplicateBindingOnAction,
		DuplicateBindingOnActionSet
	}
}


