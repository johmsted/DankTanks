﻿using UnityEngine;

namespace Ferr {
    public class Dummy : ScriptableObject {
    }
}